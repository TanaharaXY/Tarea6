/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operacion;

/**
 *
 * @author Fredo
 */
public class Main {
    
     public static void main(String[] args){
            
            Calif fredo = new Calif();
            double[] calificaciones = {89,70,51,100,62};
            fredo.setNombre("Alfredo Lara");
            fredo.setCalificacion(calificaciones);
            fredo.imprimeResultado();
            
            
            }
    
}
